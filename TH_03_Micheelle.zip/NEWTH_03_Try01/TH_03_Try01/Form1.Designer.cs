﻿namespace TH_03_Try01
{
    partial class UC_Bank
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UC_Bank));
            this.lbl_UCBank01 = new System.Windows.Forms.Label();
            this.lbl_Username01 = new System.Windows.Forms.Label();
            this.lbl_Password01 = new System.Windows.Forms.Label();
            this.txbx_Username01 = new System.Windows.Forms.TextBox();
            this.txbx_Password01 = new System.Windows.Forms.TextBox();
            this.btn_Login01 = new System.Windows.Forms.Button();
            this.btn_Register01 = new System.Windows.Forms.Button();
            this.panel_LoginView = new System.Windows.Forms.Panel();
            this.panel_Register = new System.Windows.Forms.Panel();
            this.btn_Register02 = new System.Windows.Forms.Button();
            this.txbx_Password02 = new System.Windows.Forms.TextBox();
            this.txbx_Username02 = new System.Windows.Forms.TextBox();
            this.lbl_Password02 = new System.Windows.Forms.Label();
            this.lbl_Username02 = new System.Windows.Forms.Label();
            this.lbl_UCBank02 = new System.Windows.Forms.Label();
            this.panel_Mainview = new System.Windows.Forms.Panel();
            this.btn_Withdraw03 = new System.Windows.Forms.Button();
            this.btn_Deposit03 = new System.Windows.Forms.Button();
            this.btn_Logout03 = new System.Windows.Forms.Button();
            this.lbl_Balance03 = new System.Windows.Forms.Label();
            this.lbl_Value03 = new System.Windows.Forms.Label();
            this.lbl_UCBank03 = new System.Windows.Forms.Label();
            this.panel_Withdraw = new System.Windows.Forms.Panel();
            this.lbl_Balance05 = new System.Windows.Forms.Label();
            this.lbl_Value05 = new System.Windows.Forms.Label();
            this.txbx_Withdraw05 = new System.Windows.Forms.TextBox();
            this.btn_Withdraw05 = new System.Windows.Forms.Button();
            this.btn_Logout05 = new System.Windows.Forms.Button();
            this.lbl_Amount05 = new System.Windows.Forms.Label();
            this.lbl_UCBank05 = new System.Windows.Forms.Label();
            this.panel_Deposit = new System.Windows.Forms.Panel();
            this.txbx_Deposit04 = new System.Windows.Forms.TextBox();
            this.btn_Deposit04 = new System.Windows.Forms.Button();
            this.btn_Logout04 = new System.Windows.Forms.Button();
            this.lbl_Amount04 = new System.Windows.Forms.Label();
            this.lbl_UCBank04 = new System.Windows.Forms.Label();
            this.panel_LoginView.SuspendLayout();
            this.panel_Register.SuspendLayout();
            this.panel_Mainview.SuspendLayout();
            this.panel_Withdraw.SuspendLayout();
            this.panel_Deposit.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbl_UCBank01
            // 
            this.lbl_UCBank01.AutoSize = true;
            this.lbl_UCBank01.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_UCBank01.Location = new System.Drawing.Point(8, 28);
            this.lbl_UCBank01.Name = "lbl_UCBank01";
            this.lbl_UCBank01.Size = new System.Drawing.Size(168, 40);
            this.lbl_UCBank01.TabIndex = 0;
            this.lbl_UCBank01.Text = "UC Bank";
            // 
            // lbl_Username01
            // 
            this.lbl_Username01.AutoSize = true;
            this.lbl_Username01.Location = new System.Drawing.Point(11, 86);
            this.lbl_Username01.Name = "lbl_Username01";
            this.lbl_Username01.Size = new System.Drawing.Size(91, 20);
            this.lbl_Username01.TabIndex = 1;
            this.lbl_Username01.Text = "Username :";
            // 
            // lbl_Password01
            // 
            this.lbl_Password01.AutoSize = true;
            this.lbl_Password01.Location = new System.Drawing.Point(11, 121);
            this.lbl_Password01.Name = "lbl_Password01";
            this.lbl_Password01.Size = new System.Drawing.Size(86, 20);
            this.lbl_Password01.TabIndex = 2;
            this.lbl_Password01.Text = "Password :";
            // 
            // txbx_Username01
            // 
            this.txbx_Username01.Location = new System.Drawing.Point(108, 83);
            this.txbx_Username01.Name = "txbx_Username01";
            this.txbx_Username01.Size = new System.Drawing.Size(148, 26);
            this.txbx_Username01.TabIndex = 3;
            // 
            // txbx_Password01
            // 
            this.txbx_Password01.Location = new System.Drawing.Point(108, 115);
            this.txbx_Password01.Name = "txbx_Password01";
            this.txbx_Password01.Size = new System.Drawing.Size(148, 26);
            this.txbx_Password01.TabIndex = 4;
            // 
            // btn_Login01
            // 
            this.btn_Login01.Location = new System.Drawing.Point(92, 166);
            this.btn_Login01.Name = "btn_Login01";
            this.btn_Login01.Size = new System.Drawing.Size(94, 35);
            this.btn_Login01.TabIndex = 5;
            this.btn_Login01.Text = "Login";
            this.btn_Login01.UseVisualStyleBackColor = true;
            this.btn_Login01.Click += new System.EventHandler(this.btn_Login01_Click);
            // 
            // btn_Register01
            // 
            this.btn_Register01.Location = new System.Drawing.Point(92, 207);
            this.btn_Register01.Name = "btn_Register01";
            this.btn_Register01.Size = new System.Drawing.Size(94, 35);
            this.btn_Register01.TabIndex = 6;
            this.btn_Register01.Text = "Register";
            this.btn_Register01.UseVisualStyleBackColor = true;
            this.btn_Register01.Click += new System.EventHandler(this.btn_Register01_Click);
            // 
            // panel_LoginView
            // 
            this.panel_LoginView.Controls.Add(this.btn_Register01);
            this.panel_LoginView.Controls.Add(this.btn_Login01);
            this.panel_LoginView.Controls.Add(this.txbx_Password01);
            this.panel_LoginView.Controls.Add(this.txbx_Username01);
            this.panel_LoginView.Controls.Add(this.lbl_Password01);
            this.panel_LoginView.Controls.Add(this.lbl_Username01);
            this.panel_LoginView.Controls.Add(this.lbl_UCBank01);
            this.panel_LoginView.Location = new System.Drawing.Point(12, 12);
            this.panel_LoginView.Name = "panel_LoginView";
            this.panel_LoginView.Size = new System.Drawing.Size(323, 342);
            this.panel_LoginView.TabIndex = 7;
            // 
            // panel_Register
            // 
            this.panel_Register.Controls.Add(this.btn_Register02);
            this.panel_Register.Controls.Add(this.txbx_Password02);
            this.panel_Register.Controls.Add(this.txbx_Username02);
            this.panel_Register.Controls.Add(this.lbl_Password02);
            this.panel_Register.Controls.Add(this.lbl_Username02);
            this.panel_Register.Controls.Add(this.lbl_UCBank02);
            this.panel_Register.Location = new System.Drawing.Point(12, 12);
            this.panel_Register.Name = "panel_Register";
            this.panel_Register.Size = new System.Drawing.Size(323, 342);
            this.panel_Register.TabIndex = 8;
            // 
            // btn_Register02
            // 
            this.btn_Register02.Location = new System.Drawing.Point(92, 165);
            this.btn_Register02.Name = "btn_Register02";
            this.btn_Register02.Size = new System.Drawing.Size(94, 35);
            this.btn_Register02.TabIndex = 6;
            this.btn_Register02.Text = "Register";
            this.btn_Register02.UseVisualStyleBackColor = true;
            this.btn_Register02.Click += new System.EventHandler(this.btn_Register02_Click);
            // 
            // txbx_Password02
            // 
            this.txbx_Password02.Location = new System.Drawing.Point(108, 115);
            this.txbx_Password02.Name = "txbx_Password02";
            this.txbx_Password02.Size = new System.Drawing.Size(148, 26);
            this.txbx_Password02.TabIndex = 4;
            // 
            // txbx_Username02
            // 
            this.txbx_Username02.Location = new System.Drawing.Point(108, 83);
            this.txbx_Username02.Name = "txbx_Username02";
            this.txbx_Username02.Size = new System.Drawing.Size(148, 26);
            this.txbx_Username02.TabIndex = 3;
            // 
            // lbl_Password02
            // 
            this.lbl_Password02.AutoSize = true;
            this.lbl_Password02.Location = new System.Drawing.Point(11, 121);
            this.lbl_Password02.Name = "lbl_Password02";
            this.lbl_Password02.Size = new System.Drawing.Size(86, 20);
            this.lbl_Password02.TabIndex = 2;
            this.lbl_Password02.Text = "Password :";
            // 
            // lbl_Username02
            // 
            this.lbl_Username02.AutoSize = true;
            this.lbl_Username02.Location = new System.Drawing.Point(11, 86);
            this.lbl_Username02.Name = "lbl_Username02";
            this.lbl_Username02.Size = new System.Drawing.Size(91, 20);
            this.lbl_Username02.TabIndex = 1;
            this.lbl_Username02.Text = "Username :";
            // 
            // lbl_UCBank02
            // 
            this.lbl_UCBank02.AutoSize = true;
            this.lbl_UCBank02.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_UCBank02.Location = new System.Drawing.Point(8, 28);
            this.lbl_UCBank02.Name = "lbl_UCBank02";
            this.lbl_UCBank02.Size = new System.Drawing.Size(168, 40);
            this.lbl_UCBank02.TabIndex = 0;
            this.lbl_UCBank02.Text = "UC Bank";
            // 
            // panel_Mainview
            // 
            this.panel_Mainview.Controls.Add(this.btn_Withdraw03);
            this.panel_Mainview.Controls.Add(this.btn_Deposit03);
            this.panel_Mainview.Controls.Add(this.btn_Logout03);
            this.panel_Mainview.Controls.Add(this.lbl_Balance03);
            this.panel_Mainview.Controls.Add(this.lbl_Value03);
            this.panel_Mainview.Controls.Add(this.lbl_UCBank03);
            this.panel_Mainview.Location = new System.Drawing.Point(12, 12);
            this.panel_Mainview.Name = "panel_Mainview";
            this.panel_Mainview.Size = new System.Drawing.Size(323, 346);
            this.panel_Mainview.TabIndex = 9;
            // 
            // btn_Withdraw03
            // 
            this.btn_Withdraw03.Location = new System.Drawing.Point(103, 276);
            this.btn_Withdraw03.Name = "btn_Withdraw03";
            this.btn_Withdraw03.Size = new System.Drawing.Size(128, 40);
            this.btn_Withdraw03.TabIndex = 5;
            this.btn_Withdraw03.Text = "Withdraw";
            this.btn_Withdraw03.UseVisualStyleBackColor = true;
            this.btn_Withdraw03.Click += new System.EventHandler(this.btn_Withdraw03_Click);
            // 
            // btn_Deposit03
            // 
            this.btn_Deposit03.Location = new System.Drawing.Point(103, 205);
            this.btn_Deposit03.Name = "btn_Deposit03";
            this.btn_Deposit03.Size = new System.Drawing.Size(128, 40);
            this.btn_Deposit03.TabIndex = 4;
            this.btn_Deposit03.Text = "Deposit";
            this.btn_Deposit03.UseVisualStyleBackColor = true;
            this.btn_Deposit03.Click += new System.EventHandler(this.btn_Deposit03_Click);
            // 
            // btn_Logout03
            // 
            this.btn_Logout03.Location = new System.Drawing.Point(181, 65);
            this.btn_Logout03.Name = "btn_Logout03";
            this.btn_Logout03.Size = new System.Drawing.Size(128, 40);
            this.btn_Logout03.TabIndex = 3;
            this.btn_Logout03.Text = "Log Out";
            this.btn_Logout03.UseVisualStyleBackColor = true;
            this.btn_Logout03.Click += new System.EventHandler(this.btn_Logout03_Click);
            // 
            // lbl_Balance03
            // 
            this.lbl_Balance03.AutoSize = true;
            this.lbl_Balance03.Location = new System.Drawing.Point(9, 125);
            this.lbl_Balance03.Name = "lbl_Balance03";
            this.lbl_Balance03.Size = new System.Drawing.Size(67, 20);
            this.lbl_Balance03.TabIndex = 2;
            this.lbl_Balance03.Text = "Balance";
            // 
            // lbl_Value03
            // 
            this.lbl_Value03.AutoSize = true;
            this.lbl_Value03.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Value03.Location = new System.Drawing.Point(98, 121);
            this.lbl_Value03.Name = "lbl_Value03";
            this.lbl_Value03.Size = new System.Drawing.Size(84, 25);
            this.lbl_Value03.TabIndex = 1;
            this.lbl_Value03.Text = "Rp. 0,00";
            // 
            // lbl_UCBank03
            // 
            this.lbl_UCBank03.AutoSize = true;
            this.lbl_UCBank03.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_UCBank03.Location = new System.Drawing.Point(6, 6);
            this.lbl_UCBank03.Name = "lbl_UCBank03";
            this.lbl_UCBank03.Size = new System.Drawing.Size(187, 46);
            this.lbl_UCBank03.TabIndex = 0;
            this.lbl_UCBank03.Text = "UC Bank";
            // 
            // panel_Withdraw
            // 
            this.panel_Withdraw.Controls.Add(this.lbl_Balance05);
            this.panel_Withdraw.Controls.Add(this.lbl_Value05);
            this.panel_Withdraw.Controls.Add(this.txbx_Withdraw05);
            this.panel_Withdraw.Controls.Add(this.btn_Withdraw05);
            this.panel_Withdraw.Controls.Add(this.btn_Logout05);
            this.panel_Withdraw.Controls.Add(this.lbl_Amount05);
            this.panel_Withdraw.Controls.Add(this.lbl_UCBank05);
            this.panel_Withdraw.Location = new System.Drawing.Point(12, 9);
            this.panel_Withdraw.Name = "panel_Withdraw";
            this.panel_Withdraw.Size = new System.Drawing.Size(323, 346);
            this.panel_Withdraw.TabIndex = 11;
            // 
            // lbl_Balance05
            // 
            this.lbl_Balance05.AutoSize = true;
            this.lbl_Balance05.Location = new System.Drawing.Point(10, 125);
            this.lbl_Balance05.Name = "lbl_Balance05";
            this.lbl_Balance05.Size = new System.Drawing.Size(67, 20);
            this.lbl_Balance05.TabIndex = 6;
            this.lbl_Balance05.Text = "Balance";
            // 
            // lbl_Value05
            // 
            this.lbl_Value05.AutoSize = true;
            this.lbl_Value05.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lbl_Value05.Location = new System.Drawing.Point(83, 120);
            this.lbl_Value05.Name = "lbl_Value05";
            this.lbl_Value05.Size = new System.Drawing.Size(84, 25);
            this.lbl_Value05.TabIndex = 6;
            this.lbl_Value05.Text = "Rp. 0,00";
            // 
            // txbx_Withdraw05
            // 
            this.txbx_Withdraw05.Location = new System.Drawing.Point(83, 201);
            this.txbx_Withdraw05.Name = "txbx_Withdraw05";
            this.txbx_Withdraw05.Size = new System.Drawing.Size(163, 26);
            this.txbx_Withdraw05.TabIndex = 5;
            // 
            // btn_Withdraw05
            // 
            this.btn_Withdraw05.Location = new System.Drawing.Point(103, 247);
            this.btn_Withdraw05.Name = "btn_Withdraw05";
            this.btn_Withdraw05.Size = new System.Drawing.Size(128, 40);
            this.btn_Withdraw05.TabIndex = 4;
            this.btn_Withdraw05.Text = "Withdraw";
            this.btn_Withdraw05.UseVisualStyleBackColor = true;
            this.btn_Withdraw05.Click += new System.EventHandler(this.btn_Withdraw05_Click);
            // 
            // btn_Logout05
            // 
            this.btn_Logout05.Location = new System.Drawing.Point(181, 65);
            this.btn_Logout05.Name = "btn_Logout05";
            this.btn_Logout05.Size = new System.Drawing.Size(128, 40);
            this.btn_Logout05.TabIndex = 3;
            this.btn_Logout05.Text = "Log Out";
            this.btn_Logout05.UseVisualStyleBackColor = true;
            this.btn_Logout05.Click += new System.EventHandler(this.btn_Logout05_Click);
            // 
            // lbl_Amount05
            // 
            this.lbl_Amount05.AutoSize = true;
            this.lbl_Amount05.Location = new System.Drawing.Point(77, 167);
            this.lbl_Amount05.Name = "lbl_Amount05";
            this.lbl_Amount05.Size = new System.Drawing.Size(196, 20);
            this.lbl_Amount05.TabIndex = 2;
            this.lbl_Amount05.Text = "Input Withdrawal Amount :";
            // 
            // lbl_UCBank05
            // 
            this.lbl_UCBank05.AutoSize = true;
            this.lbl_UCBank05.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_UCBank05.Location = new System.Drawing.Point(6, 6);
            this.lbl_UCBank05.Name = "lbl_UCBank05";
            this.lbl_UCBank05.Size = new System.Drawing.Size(187, 46);
            this.lbl_UCBank05.TabIndex = 0;
            this.lbl_UCBank05.Text = "UC Bank";
            // 
            // panel_Deposit
            // 
            this.panel_Deposit.Controls.Add(this.txbx_Deposit04);
            this.panel_Deposit.Controls.Add(this.btn_Deposit04);
            this.panel_Deposit.Controls.Add(this.btn_Logout04);
            this.panel_Deposit.Controls.Add(this.lbl_Amount04);
            this.panel_Deposit.Controls.Add(this.lbl_UCBank04);
            this.panel_Deposit.Location = new System.Drawing.Point(12, 9);
            this.panel_Deposit.Name = "panel_Deposit";
            this.panel_Deposit.Size = new System.Drawing.Size(323, 346);
            this.panel_Deposit.TabIndex = 10;
            // 
            // txbx_Deposit04
            // 
            this.txbx_Deposit04.Location = new System.Drawing.Point(83, 201);
            this.txbx_Deposit04.Name = "txbx_Deposit04";
            this.txbx_Deposit04.Size = new System.Drawing.Size(163, 26);
            this.txbx_Deposit04.TabIndex = 5;
            // 
            // btn_Deposit04
            // 
            this.btn_Deposit04.Location = new System.Drawing.Point(103, 247);
            this.btn_Deposit04.Name = "btn_Deposit04";
            this.btn_Deposit04.Size = new System.Drawing.Size(128, 40);
            this.btn_Deposit04.TabIndex = 4;
            this.btn_Deposit04.Text = "Deposit";
            this.btn_Deposit04.UseVisualStyleBackColor = true;
            this.btn_Deposit04.Click += new System.EventHandler(this.btn_Deposit04_Click);
            // 
            // btn_Logout04
            // 
            this.btn_Logout04.Location = new System.Drawing.Point(181, 65);
            this.btn_Logout04.Name = "btn_Logout04";
            this.btn_Logout04.Size = new System.Drawing.Size(128, 40);
            this.btn_Logout04.TabIndex = 3;
            this.btn_Logout04.Text = "Log Out";
            this.btn_Logout04.UseVisualStyleBackColor = true;
            this.btn_Logout04.Click += new System.EventHandler(this.btn_Logout04_Click);
            // 
            // lbl_Amount04
            // 
            this.lbl_Amount04.AutoSize = true;
            this.lbl_Amount04.Location = new System.Drawing.Point(77, 167);
            this.lbl_Amount04.Name = "lbl_Amount04";
            this.lbl_Amount04.Size = new System.Drawing.Size(173, 20);
            this.lbl_Amount04.TabIndex = 2;
            this.lbl_Amount04.Text = "Input Deposit Amount :";
            // 
            // lbl_UCBank04
            // 
            this.lbl_UCBank04.AutoSize = true;
            this.lbl_UCBank04.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_UCBank04.Location = new System.Drawing.Point(6, 6);
            this.lbl_UCBank04.Name = "lbl_UCBank04";
            this.lbl_UCBank04.Size = new System.Drawing.Size(187, 46);
            this.lbl_UCBank04.TabIndex = 0;
            this.lbl_UCBank04.Text = "UC Bank";
            // 
            // UC_Bank
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(349, 375);
            this.Controls.Add(this.panel_Withdraw);
            this.Controls.Add(this.panel_Deposit);
            this.Controls.Add(this.panel_Mainview);
            this.Controls.Add(this.panel_Register);
            this.Controls.Add(this.panel_LoginView);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "UC_Bank";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "UC_Bank";
            this.Load += new System.EventHandler(this.UC_Bank_Load);
            this.panel_LoginView.ResumeLayout(false);
            this.panel_LoginView.PerformLayout();
            this.panel_Register.ResumeLayout(false);
            this.panel_Register.PerformLayout();
            this.panel_Mainview.ResumeLayout(false);
            this.panel_Mainview.PerformLayout();
            this.panel_Withdraw.ResumeLayout(false);
            this.panel_Withdraw.PerformLayout();
            this.panel_Deposit.ResumeLayout(false);
            this.panel_Deposit.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lbl_UCBank01;
        private System.Windows.Forms.Label lbl_Username01;
        private System.Windows.Forms.Label lbl_Password01;
        private System.Windows.Forms.TextBox txbx_Username01;
        private System.Windows.Forms.TextBox txbx_Password01;
        private System.Windows.Forms.Button btn_Login01;
        private System.Windows.Forms.Button btn_Register01;
        private System.Windows.Forms.Panel panel_LoginView;
        private System.Windows.Forms.Panel panel_Register;
        private System.Windows.Forms.Button btn_Register02;
        private System.Windows.Forms.TextBox txbx_Password02;
        private System.Windows.Forms.TextBox txbx_Username02;
        private System.Windows.Forms.Label lbl_Password02;
        private System.Windows.Forms.Label lbl_Username02;
        private System.Windows.Forms.Label lbl_UCBank02;
        private System.Windows.Forms.Panel panel_Mainview;
        private System.Windows.Forms.Button btn_Withdraw03;
        private System.Windows.Forms.Button btn_Deposit03;
        private System.Windows.Forms.Button btn_Logout03;
        private System.Windows.Forms.Label lbl_Balance03;
        private System.Windows.Forms.Label lbl_Value03;
        private System.Windows.Forms.Label lbl_UCBank03;
        private System.Windows.Forms.Panel panel_Withdraw;
        private System.Windows.Forms.Label lbl_Balance05;
        private System.Windows.Forms.Label lbl_Value05;
        private System.Windows.Forms.TextBox txbx_Withdraw05;
        private System.Windows.Forms.Button btn_Withdraw05;
        private System.Windows.Forms.Button btn_Logout05;
        private System.Windows.Forms.Label lbl_Amount05;
        private System.Windows.Forms.Label lbl_UCBank05;
        private System.Windows.Forms.Panel panel_Deposit;
        private System.Windows.Forms.TextBox txbx_Deposit04;
        private System.Windows.Forms.Button btn_Deposit04;
        private System.Windows.Forms.Button btn_Logout04;
        private System.Windows.Forms.Label lbl_Amount04;
        private System.Windows.Forms.Label lbl_UCBank04;
    }
}

