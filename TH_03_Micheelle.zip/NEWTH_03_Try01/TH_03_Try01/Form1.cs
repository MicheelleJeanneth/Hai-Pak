﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH_03_Try01
{
    public partial class UC_Bank : Form
    {
        DataTable username = new DataTable();
        
        int userke;
        public UC_Bank()
        {
            InitializeComponent(); 
            panel_Register.Visible = false;
            panel_LoginView.Visible = true;
            panel_Mainview.Visible = false;
            panel_Deposit.Visible = false;
            panel_Withdraw.Visible = false;
        }

        private void btn_Register01_Click(object sender, EventArgs e)
        {
            panel_Register.Visible = true;
            panel_LoginView.Visible = false;
            panel_Mainview.Visible = false;
            panel_Deposit.Visible = false;
            panel_Withdraw.Visible = false;
        }

        private void btn_Login01_Click(object sender, EventArgs e)
        {
            bool terdaftar = false;
            bool password = false;

            if (username.Rows.Count != 0)
            {
                for (int i = 0; i < username.Rows.Count; i++)
                {
                    if (txbx_Username01.Text == username.Rows[i][0].ToString())
                    {
                        if (txbx_Password01.Text == username.Rows[i][1].ToString())
                        {
                            terdaftar = true;
                            password = true;
                            userke = i;
                            break;
                        }
                        else
                        {
                            terdaftar = true; 
                            password = false;
                            break;
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Please Register First");
                txbx_Username01.Text = "";
                txbx_Password01.Text = "";
                terdaftar = false;
            }

            if (terdaftar == true && password == true)
            {
                MessageBox.Show("Login Successful");
                lbl_Value03.Text = "Rp. " + Convert.ToInt32(username.Rows[userke][2]).ToString("C2").Remove(0, 1);
                panel_Register.Visible = false;
                panel_LoginView.Visible = false;
                panel_Mainview.Visible = true;
                panel_Deposit.Visible = false;
                panel_Withdraw.Visible = false;
            }
            else if (username.Rows.Count != 0 && password == false)
            {
                MessageBox.Show("Password Wrong! Please Try Again");
            }
            txbx_Username01.Text = "";
            txbx_Password01.Text = "";
        }

        private void btn_Register02_Click(object sender, EventArgs e)
        {
            bool sama = false;

            if (username.Rows.Count != 0)
            {
                for (int i = 0; i < username.Rows.Count; i++)
                {
                    if (txbx_Username02.Text == username.Rows[i][0].ToString())
                    {
                        sama = true;
                        break;
                    }
                    else
                    {
                        sama = false;
                    }
                }
            }

            if (sama == false)
            {
                username.Rows.Add(txbx_Username02.Text, txbx_Password02.Text, 0);
                MessageBox.Show("Register Successful");
            }
            else if (sama == true)
            {
                MessageBox.Show("Username Has Been Used");
                txbx_Username02.Text = "";
                txbx_Password02.Text = "";
            }

            txbx_Username01.Text = "";
            txbx_Password01.Text = "";
            txbx_Username02.Text = "";
            txbx_Password02.Text = "";
            panel_Register.Visible = false;
            panel_LoginView.Visible = true;
            panel_Mainview.Visible = false;
            panel_Deposit.Visible = false;
            panel_Withdraw.Visible = false;
        }

        private void label1_Click(object sender, EventArgs e)
        {
        }

        private void UC_Bank_Load(object sender, EventArgs e)
        {
            username.Columns.Add("Username");
            username.Columns.Add("Password");
            username.Columns.Add("Money");
        }

        private void btn_Deposit03_Click(object sender, EventArgs e)
        {
            panel_Register.Visible = false;
            panel_LoginView.Visible = false;
            panel_Mainview.Visible = false;
            panel_Deposit.Visible = true;
            panel_Withdraw.Visible = false;
        }

        private void btn_Deposit04_Click(object sender, EventArgs e)
        {
            if (Convert.ToInt32(txbx_Deposit04.Text) > 0)
            {
                int amount = Convert.ToInt32(txbx_Deposit04.Text);
                int a = Convert.ToInt32(username.Rows[userke][2].ToString()); 
                a = a + amount;
                lbl_Value03.Text = "Rp. " + a.ToString("C2").Remove(0, 1);
                username.Rows[userke][2] = a;
                MessageBox.Show("Successfully Add Deposit");
                panel_Register.Visible = false;
                panel_LoginView.Visible = false;
                panel_Mainview.Visible = true;
                panel_Deposit.Visible = false;
                panel_Withdraw.Visible = false;
            }
            else
            {
                MessageBox.Show("Deposit Amount Can't Be Less Than 1");
            }
            txbx_Deposit04.Text = "";
        }

        private void btn_Logout04_Click(object sender, EventArgs e)
        {
        }

        private void btn_Withdraw03_Click(object sender, EventArgs e)
        {
            panel_Register.Visible = false;
            panel_LoginView.Visible = false;
            panel_Mainview.Visible = false;
            panel_Deposit.Visible = false;
            panel_Withdraw.Visible = true;
            lbl_Value05.Text = lbl_Value03.Text;
        }

        private void btn_Withdraw05_Click(object sender, EventArgs e)
        {
            int value = Convert.ToInt32(txbx_Withdraw05.Text);
            int v = Convert.ToInt32(username.Rows[userke][2].ToString());
            lbl_Value05.Text = lbl_Value03.Text;
            if (value > 0 && value <= v)
            {
                int with = v - value;
                username.Rows[userke][2] = with;
                MessageBox.Show("Successfully Withdraw");
                panel_Register.Visible = false;
                panel_LoginView.Visible = false;
                panel_Mainview.Visible = true;
                panel_Deposit.Visible = false;
                panel_Withdraw.Visible = false;
                lbl_Value03.Text = "Rp. " + with.ToString("C2").Remove(0, 1);
                lbl_Value05.Text = "Rp. " + with.ToString("C2").Remove(0, 1);
            }
            else if (value > v)
            {
                MessageBox.Show("Withdraw Failed! Not Enough Balance");
            }
            else if (value <= 0)
            {
                MessageBox.Show("Withdraw Amount Can't Be Less Than 1");
            }
            txbx_Withdraw05.Text = " ";
        }

        private void btn_Logout05_Click(object sender, EventArgs e)
        {
            panel_Register.Visible = false;
            panel_LoginView.Visible = false;
            panel_Mainview.Visible = true;
            panel_Deposit.Visible = false;
            panel_Withdraw.Visible = false;
        }

        private void btn_Logout03_Click(object sender, EventArgs e)
        {
            panel_Register.Visible = false;
            panel_LoginView.Visible = true;
            panel_Mainview.Visible = false;
            panel_Deposit.Visible = false;
            panel_Withdraw.Visible = false;
        }
    }
}